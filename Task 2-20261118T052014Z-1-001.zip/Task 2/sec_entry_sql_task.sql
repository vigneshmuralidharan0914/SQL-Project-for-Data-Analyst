

DESC employees;
DESC departments;
DESC location;

DESCRIBE employees;
DESCRIBE departments;
DESCRIBE location;


DESC employees;

SELECT
    Age AS Employee_Age,
    Salary AS Employee_Salary
FROM employees;

SET SQL_SAFE_UPDATES = 0;
UPDATE employees
SET Designation = 'Data Scientist'
WHERE Designation IS NULL;

DESC employees;

SELECT *
FROM employees
WHERE Salary > 50000
AND HireDate < '2016-01-01';

SHOW COLUMNS FROM employees;

SELECT *
FROM employees
WHERE Salary > 50000
AND hire_date < '2016-01-01';

UPDATE employees
SET Designation = 'Data Scientist'
WHERE Designation IS NULL;

SELECT *
FROM employees
ORDER BY Salary DESC;
SELECT * FROM employees LIMIT 1;

SELECT *
FROM employees
WHERE YEAR(hire_date) = 2018
LIMIT 5;

SELECT SUM(e.Salary) AS TotalSalary
FROM employees e
INNER JOIN departments d
ON e.department_id = d.department_id
WHERE d.department_name = 'Finance';

SELECT MIN(age) AS MinimumAge
FROM employees;

SHOW COLUMNS FROM location;

SHOW COLUMNS FROM location;

SELECT
    l.location,
    MAX(e.Salary) AS MaxSalary
FROM employees e
INNER JOIN location l
ON e.location_id = l.location_id
GROUP BY l.location;

SELECT
    Designation,
    AVG(Salary) AS AverageSalary
FROM employees
WHERE Designation LIKE '%Analyst%'
GROUP BY Designation;

SHOW COLUMNS FROM employees;

SELECT
    department_id,
    COUNT(employee_id) AS TotalEmployees
FROM employees
GROUP BY department_id
HAVING COUNT(employee_id) < 3;

SHOW COLUMNS FROM employees;

SELECT
    l.location,
    AVG(e.age) AS AverageAge
FROM employees e
INNER JOIN location l
ON e.location_id = l.location_id
WHERE e.gender = 'F'
GROUP BY l.location
HAVING AVG(e.age) < 30;

SELECT
    e.employee_name,
    e.Designation,
    d.department_name
FROM employees e
INNER JOIN departments d
ON e.department_id = d.department_id;

SELECT
    d.department_name,
    COUNT(e.employee_id) AS TotalEmployees
FROM departments d
LEFT JOIN employees e
ON d.department_id = e.department_id
GROUP BY d.department_id, d.department_name;

SELECT
    l.location,
    e.employee_name
FROM employees e
RIGHT JOIN location l
ON e.location_id = l.location_id;
