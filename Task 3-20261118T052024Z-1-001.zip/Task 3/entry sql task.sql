-- ============================================================
-- Assignment: Analyzing E-Learning Platform Purchases using MySQL
-- ============================================================

-- ---------------------------------
-- STEP 1: CREATE DATABASE
-- ---------------------------------
CREATE DATABASE IF NOT EXISTS elearning_db;
USE elearning_db;

-- ---------------------------------
-- STEP 2: CREATE TABLES
-- ---------------------------------

CREATE TABLE learners (
    learner_id  INT PRIMARY KEY AUTO_INCREMENT,
    full_name   VARCHAR(100) NOT NULL,
    country     VARCHAR(50) NOT NULL
);

CREATE TABLE courses (
    course_id   INT PRIMARY KEY AUTO_INCREMENT,
    course_name VARCHAR(100) NOT NULL,
    category    VARCHAR(50) NOT NULL,
    unit_price  DECIMAL(10,2) NOT NULL
);

CREATE TABLE purchases (
    purchase_id   INT PRIMARY KEY AUTO_INCREMENT,
    learner_id    INT NOT NULL,
    course_id     INT NOT NULL,
    quantity      INT NOT NULL,
    purchase_date DATE NOT NULL,
    FOREIGN KEY (learner_id) REFERENCES learners(learner_id),
    FOREIGN KEY (course_id)  REFERENCES courses(course_id)
);

-- ---------------------------------
-- STEP 3: INSERT SAMPLE DATA
-- ---------------------------------

-- 5 learners
INSERT INTO learners (full_name, country) VALUES
('Arjun Kumar', 'India'),
('Sara Johnson', 'USA'),
('Mohammed Ali', 'UAE'),
('Li Wei', 'China'),
('Emma Watson', 'UK');

-- 5 courses across multiple categories
INSERT INTO courses (course_name, category, unit_price) VALUES
('Python for Data Science', 'Data Science', 49.99),
('Web Development Bootcamp', 'Web Development', 59.99),
('Graphic Design Basics', 'Design', 29.99),
('Digital Marketing 101', 'Marketing', 39.99),
('Excel Mastery', 'Business', 19.99);   -- this course will remain unpurchased (used for Q5)

-- 8 purchase records
INSERT INTO purchases (learner_id, course_id, quantity, purchase_date) VALUES
(1, 1, 2, '2024-01-10'),   -- Arjun buys Python course
(1, 3, 1, '2024-02-15'),   -- Arjun buys Design course too (2 categories)
(2, 2, 1, '2024-01-20'),   -- Sara buys Web Dev
(2, 4, 2, '2024-03-05'),   -- Sara buys Marketing too (2 categories)
(3, 1, 1, '2024-01-25'),   -- Mohammed buys Python
(4, 2, 3, '2024-02-10'),   -- Li Wei buys Web Dev
(5, 3, 2, '2024-03-15'),   -- Emma buys Design
(5, 1, 1, '2024-04-01');   -- Emma buys Python too (2 categories)

-- ============================================================
-- STEP 4: DATA EXPLORATION USING JOINS
-- ============================================================

-- (A) INNER JOIN -> only learners who actually purchased something
SELECT
    l.full_name          AS learner_name,
    c.course_name         AS course_name,
    c.category            AS category,
    p.quantity            AS quantity,
    FORMAT(p.quantity * c.unit_price, 2) AS total_amount,
    p.purchase_date       AS purchase_date
FROM purchases p
INNER JOIN learners l ON p.learner_id = l.learner_id
INNER JOIN courses  c ON p.course_id  = c.course_id
ORDER BY (p.quantity * c.unit_price) DESC;

-- (B) LEFT JOIN -> all learners, even if they never purchased (none here, but shows the logic)
SELECT
    l.full_name          AS learner_name,
    c.course_name         AS course_name,
    c.category            AS category,
    p.quantity             AS quantity,
    FORMAT(p.quantity * c.unit_price, 2) AS total_amount,
    p.purchase_date        AS purchase_date
FROM learners l
LEFT JOIN purchases p ON l.learner_id = p.learner_id
LEFT JOIN courses  c ON p.course_id  = c.course_id
ORDER BY l.full_name;

-- (C) RIGHT JOIN -> all courses, even the ones nobody purchased
SELECT
    l.full_name          AS learner_name,
    c.course_name         AS course_name,
    c.category            AS category,
    p.quantity             AS quantity,
    FORMAT(p.quantity * c.unit_price, 2) AS total_amount,
    p.purchase_date        AS purchase_date
FROM purchases p
RIGHT JOIN courses  c ON p.course_id  = c.course_id
LEFT  JOIN learners l ON p.learner_id = l.learner_id
ORDER BY c.course_name;

-- ============================================================
-- STEP 5: ANALYTICAL QUERIES (Q1 - Q5)
-- ============================================================

-- Q1: Each learner's total spending along with their country
SELECT
    l.full_name                          AS learner_name,
    l.country                            AS country,
    FORMAT(SUM(p.quantity * c.unit_price), 2) AS total_spent
FROM learners l
JOIN purchases p ON l.learner_id = p.learner_id
JOIN courses  c  ON p.course_id  = c.course_id
GROUP BY l.learner_id, l.full_name, l.country
ORDER BY SUM(p.quantity * c.unit_price) DESC;

-- Q2: Top 3 most purchased courses based on total quantity sold
SELECT
    c.course_name                AS course_name,
    SUM(p.quantity)               AS total_quantity_sold
FROM purchases p
JOIN courses c ON p.course_id = c.course_id
GROUP BY c.course_id, c.course_name
ORDER BY total_quantity_sold DESC
LIMIT 3;

-- Q3: Each category's total revenue and number of unique learners
SELECT
    c.category                                 AS category,
    FORMAT(SUM(p.quantity * c.unit_price), 2)  AS total_revenue,
    COUNT(DISTINCT p.learner_id)                AS unique_learners
FROM purchases p
JOIN courses c ON p.course_id = c.course_id
GROUP BY c.category
ORDER BY SUM(p.quantity * c.unit_price) DESC;

-- Q4: Learners who purchased courses from more than one category
SELECT
    l.full_name                     AS learner_name,
    COUNT(DISTINCT c.category)       AS category_count
FROM learners l
JOIN purchases p ON l.learner_id = p.learner_id
JOIN courses  c  ON p.course_id  = c.course_id
GROUP BY l.learner_id, l.full_name
HAVING COUNT(DISTINCT c.category) > 1
ORDER BY category_count DESC;

-- Q5: Courses that have not been purchased at all
SELECT
    c.course_name AS course_name
FROM courses c
LEFT JOIN purchases p ON c.course_id = p.course_id
WHERE p.purchase_id IS NULL;